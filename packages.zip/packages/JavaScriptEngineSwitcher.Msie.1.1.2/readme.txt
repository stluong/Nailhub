﻿

   ----------------------------------------------------------------------
      README file for JavaScript Engine Switcher for .Net: MSIE 1.1.2

   ----------------------------------------------------------------------

          Copyright 2014 Andrey Taritsyn - http://www.taritsyn.ru
		  
		  
   ===========
   DESCRIPTION
   ===========   
   JavaScriptEngineSwitcher.Msie contains adapter `MsieJsEngine` (wrapper 
   for the MSIE JavaScript Engine for .Net
   (http://github.com/Taritsyn/MsieJavaScriptEngine)). For correct 
   working of the MSIE JavaScript Engine it is recommended to install 
   Internet Explorer 9 and above on a server.
   
   =============
   RELEASE NOTES
   =============
   Added support of MSIE JavaScript Engine version 1.4.0.

   =============
   DOCUMENTATION
   =============
   See documentation on GitHub - 
   http://github.com/Taritsyn/JavaScriptEngineSwitcher